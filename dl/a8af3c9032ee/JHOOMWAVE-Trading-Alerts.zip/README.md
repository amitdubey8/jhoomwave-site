# Trading Alert Sounds (JHOOMWAVE)

Nine short alert sounds for a trading app. You can tell what happened from the sound alone, without looking at the screen.

**Ownership:** these are original sounds owned by JHOOMWAVE. Every sound was synthesized from scratch in code (`make_alerts.py`: plain sine waves, FM synthesis and filtered tones). No samples, no paid services, and no copying of any existing app or brand sound.

## How to read the sounds

| Shape | Meaning |
|---|---|
| Pitch goes **up** | BUY (bullish) |
| Pitch goes **down** | SELL (bearish) |
| **2 notes**, short | ENTRY (trade opened) |
| **3 notes** that land on a "home" note | EXIT / TAKE-PROFIT (trade done) |
| **2 low, harsh buzzes** | STOP-LOSS (urgent) |
| Same note twice, soft | Neutral PRICE ALERT |

| Family | Sound | Used for |
|---|---|---|
| `gold_*` | Bright metallic bells with a shimmer (FM bells) | Gold (XAU) |
| `general_*` | Clean wooden marimba / pluck | Stocks, forex, crypto and all other assets |

## The sounds

Loudness and peak were measured on the master WAV with ffmpeg `ebur128`. The target is -16 LUFS, with true peak at or below -1 dBFS.

| File | Meaning | Note pattern | Length | Loudness | True peak |
|---|---|---|---|---|---|
| `gold_buy_entry` | Gold: BUY trade opened | G5 → D6 (up a fifth), bell | 0.85 s | -16.0 LUFS | -2.3 dBTP |
| `gold_sell_entry` | Gold: SELL trade opened | D6 → G5 (down a fifth), bell | 0.85 s | -16.0 LUFS | -2.7 dBTP |
| `gold_exit_take_profit` | Gold: trade closed / profit taken | E5 → G5 → C6 (lands on home note), bell | 1.25 s | -16.0 LUFS | -3.0 dBTP |
| `gold_stop_loss` | Gold: STOP-LOSS hit | 2 low buzzes (~98 Hz plus a tense tritone), the 2nd slightly lower, with a metallic clang | 0.75 s | -16.0 LUFS | -4.6 dBTP |
| `general_buy_entry` | Other asset: BUY trade opened | G5 → D6 (up a fifth), marimba | 0.85 s | -16.0 LUFS | -2.2 dBTP |
| `general_sell_entry` | Other asset: SELL trade opened | D6 → G5 (down a fifth), marimba | 0.85 s | -16.0 LUFS | -1.9 dBTP |
| `general_exit_take_profit` | Other asset: trade closed / profit taken | E5 → G5 → C6 (lands on home note), marimba | 1.25 s | -16.1 LUFS | -1.8 dBTP |
| `general_stop_loss` | Other asset: STOP-LOSS hit | 2 low buzzes (~98 Hz plus a tritone), the 2nd slightly lower, with a wooden knock | 0.75 s | -16.0 LUFS | -4.3 dBTP |
| `price_alert` | Neutral: a price level was reached | A5 ping, then a softer A5 echo (same pitch, so no direction) | 0.90 s | -16.0 LUFS | -3.6 dBTP |

The full measurements for every format are in `measurements.json`. The MP3, OGG and M4A files measure within 0.4 LU of the WAV, and all of them peak below -1.2 dBTP. The MP3 files are about 40 ms longer because the encoder adds padding.

`all_alerts_preview.mp3` plays all nine sounds in the order above, with 0.8 s of silence between them (14.7 s total).

## Formats

Every sound comes in four formats, all at 48 kHz mono:
- `.wav`: 16-bit PCM master
- `.mp3`: 192 kbps
- `.ogg`: Vorbis, for Android
- `.m4a`: AAC, for iOS and web

## App notes

**Android:** put the `.ogg` files (or the `.mp3` files) in `res/raw/`. The file names are already lowercase with underscores, which Android requires. Assign each sound to its own **notification channel**, for example "Gold buy entry" or "Stop-loss". On Android 8 and later the sound belongs to the channel, so you have to set it when you create the channel. You cannot change it afterwards without making a new channel ID.

**iOS:** a notification sound must be **shorter than 30 seconds**, and all of these are under 2 s. It also has to be `.caf`, `.aiff` or `.wav` (linear PCM or IMA4) and shipped inside the app bundle or in `Library/Sounds`. You can use the `.wav` files as they are. To make `.caf` files on a Mac, run this one line in the folder:

```
for f in *.wav; do afconvert -f caff -d LEI16@48000 "$f" "${f%.wav}.caf"; done
```

The `.m4a` files are for in-app playback, such as AVAudioPlayer or a web player. They are not for push-notification sounds.

## Rebuilding

```
/home/user/ai-dj/.venv/bin/python make_alerts.py
```

This needs numpy and ffmpeg. It rebuilds every file and prints the measurement table again.

## Honest limits

These sounds were checked with objective tests only: length, loudness, peak, no clipped samples, and a pitch check that buy goes up, sell goes down and exit lands on C6. Nobody has listened to them yet. A human listening test (the founder's ears) is still needed, ideally on a real phone speaker.
